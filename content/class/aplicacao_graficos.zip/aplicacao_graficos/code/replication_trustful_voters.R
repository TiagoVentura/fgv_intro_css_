####################################################################
# Paper: Trustful Voters
# Figuras: 2
# pagina: 22
# Pedintes: Ana Julia, Yasmin, Lucas, Rene.
#####################################################################


# Pacotes -----------------------------------------------------------------
library(tidyverse)
library(janitor)
library(lubridate)
library(scales)
library(conflicted)
library(rebus)
library(extrafont)
library(patchwork)
library(summarytools)
conflict_prefer("filter", "dplyr")
conflict_prefer("select", "dplyr")

# Dados -------------------------------------------------------------------

load("data/ACSV_data.Rdata")

d <- d_reduced  %>%
              mutate_at(vars(trust_exp, invest_stage_1, invest_stage_2, invest_stage_3,
                             delegate_stage_1, delegate_stage_2, delegate_stage_3),
                              ~ na_if(.x, "-999"))


# Transition matrix -------------------------------------------------------

tile_skeleton_d <- expand_grid(delegate_stage_1=0:10, delegate_stage_2=0:10) %>%
  mutate_all(as.character)

tile_delegate <- d %>% select(ipaddress,
                              delegate_stage_1, delegate_stage_2) %>%
  group_by(delegate_stage_1, delegate_stage_2) %>%
  summarise(transfer=n()) %>%
  drop_na() %>%
  mutate_at(vars(contains("delegate")), as.character)


# get the total
tile_total_d <- d %>%
  count(delegate_stage_1, name="total") %>%
  drop_na() %>%
  mutate(delegate_stage_1=as.character(delegate_stage_1))


# Mergem them
tile_merge_d <- tile_skeleton_d %>%
  left_join(tile_total_d) %>%
  left_join(tile_delegate) %>%
  mutate(transfer=ifelse(is.na(transfer), 0, transfer),
         prop=transfer/total) %>%
  mutate_at(vars(delegate_stage_1, delegate_stage_2), ~
              fct_relevel(.x, paste(0:10)))

# graph point
ggplot(tile_merge_d, aes(y=delegate_stage_2, x=delegate_stage_1,
                         alpha=prop,
                         size=prop,
                         fill=prop)) +
  geom_point(shape=21) +
  scale_size(range = c(.001, 32)) +
  scale_alpha(range = c(.01, 1)) +
  scale_fill_gradient(low="blue", high="darkblue",
                      name="Transition in Trust") +
  geom_abline(intercept=0, slope=1, color="white",
              size=1.5) +
  theme(
    panel.grid.minor = element_blank(),
    panel.border = element_blank()) +
  labs(title="",
       x="Delegate Decision (Stage 1)",
       y="Delegate Decision (Stage 2)"
       #caption="Each circle represents the share of respondents whom delegated ''n'' votes in the second stage of the game
       #over ''d'' votes delegated in the first stage. Circles above the white line indicates an increase in delegation while
       #circles below suggest a decrease in Trust"
  ) +
  guides(size=FALSE, alpha=FALSE)


ggsave(filename="./output/figure2_trustful_voters.png",
       width = 12, height = 8, units = "in", pointsize = 12, bg = "white")
