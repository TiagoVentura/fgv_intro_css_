####################################################################
# Paper:Streaming Chats
# Figuras: 2
# pagina: 19
# Pedintes: Vinicius.
###############################################################


# Pacotes -----------------------------------------------------------------
library(tidyverse)
load("data/538_scores_toxicity.Rdata")
load("data/fb_scores_toxicity.Rdata")



# Preparacao Dados --------------------------------------------------------


relevel <- c("Expert Chat"="Fivethirtyeight",
             "Facebook Chat"="Facebook")

# bind all and prepare the data

d <- bind_rows(expert_scores, facebook_scores)


d <- d %>%
     pivot_longer(cols=-c(document, text, source, error),
                  names_to="key",
                  values_to="value") %>%
     mutate(Treatment = fct_recode(source, !!!relevel),
            key=str_to_title(key),
            key=str_replace_all(key, "_", " "))

# Proportion

d_proportions <- d %>%
              group_by(Treatment, key) %>%
              mutate(n=n(),
                     value_recoded=ifelse(value>.5, 1, 0),
                     value_recoded=sum(value_recoded, na.rm = TRUE),
                     prop_offensive=value_recoded/n) %>%
              ungroup() %>%
              distinct(Treatment, key, prop_offensive)

# Grafico

ggplot(d_proportions,
       aes(x=Treatment, y=prop_offensive, fill=Treatment)) +
  geom_col(alpha=.5, width = .8, color="black") +
  scale_y_continuous(expand = c(0,0),
                     limits = c(0, .2),
                     labels = percent_format()) +
  scale_fill_manual(values = c("darkred", "blue4"), name="") +
  theme_bw() +
  theme(plot.title = element_text(size = 22, face="bold"),
        plot.subtitle = element_text(size = 13),
        axis.title.x  = element_text(size=16, face="italic", hjust=1),
        axis.title.y = element_text(size=16),
        axis.text.x =  element_blank(),
        axis.ticks = element_blank(),
        strip.text = element_text(size=22),
        legend.title = element_blank(),
        legend.text = element_text(size = 18),
        legend.key = element_rect(color = NA, fill = NA),
        legend.key.size = unit(1.5, "cm")) +
  labs(x = NULL, y = "Share of Toxic Comments") +
  facet_grid(.~ key )

ggsave("output/proportion_toxicity.png", width = 12, height = 8, units = "in", pointsize = 12, bg = "white")


