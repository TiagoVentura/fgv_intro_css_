####################################################################
# Paper: Will I get Covid?
# Figuras: 2
# pagina: 9
# Pedintes: Antonia + Maju.
#####################################################################

# Packages ----------------------------------------------------------------
library(tidyverse)
library(summarytools)
library(lubridate)
library(scales)
library(conflicted)
library(rebus)
library(patchwork)
library(extrafont)
library(broom)
library(tidyr)
library(here)
conflict_prefer("filter", "dplyr")
conflict_prefer("select", "dplyr")


# Download the data -------------------------------------------------------
load("data/CV_data.Rdata")



# Formatting my graph -----------------------------------------------------

# ggplot theme ------------------------------------------------------------
my_font <- "Palatino Linotype"
my_bkgd <- "white"
pal <- RColorBrewer::brewer.pal(9, "Spectral")
my_theme <- theme(text = element_text(family = my_font, color = "#22211d"),
                  rect = element_rect(fill = my_bkgd),
                  plot.background = element_rect(fill = my_bkgd, color = NA),
                  panel.background = element_rect(fill = my_bkgd, color = NA),
                  panel.border = element_rect(color="black"),
                  strip.background = element_rect(color="black", fill="gray85"),
                  legend.background = element_rect(fill = my_bkgd, color = NA),
                  legend.key = element_rect(size = 6, fill = "white", colour = NA),
                  legend.key.size = unit(1, "cm"),
                  legend.text = element_text(size = 14, family = my_font),
                  legend.title = element_text(size=14),
                  plot.title = element_text(size = 22, face = "bold", family=my_font),
                  plot.subtitle = element_text(size=16, family=my_font),
                  axis.title= element_text(size=22),

                  axis.text = element_text(size=14, family=my_font),
                  axis.title.x = element_text(hjust=1),
                  strip.text = element_text(family = my_font, color = "#22211d",
                                            size = 13, face="italic"))
theme_set(theme_bw() + my_theme)




# Levels for Covid --------------------------------------------------------
levels_covid <- c( "Somewhat Likely"="Algo provável",
                   "Very Likely"= "Muito provável" ,
                   "Somewhat unlikely" = "Pouco provável",
                   "Very unlikely" = "Nada provável",
                   "Somewhat Appropriate" = "Algo adequada",
                   "Very Appropriate" = "Muito adequada",
                   "Somewhat Unappropriate" = "Pouco adequada",
                   "Not Appropriate" = "Nada adequada")

# Figure 2  ---------------------------------------------------------------



outcomes_haddad <- map_df(c("covid_government", "covid_health", "covid_job"), ~
                            lm(as.numeric(get(.x)) ~ runoff_haddad +
                                 income + gender + work +
                                 as.numeric(education) + age , data=d) %>%
                            tidy(.) %>%
                            mutate(outcome=.x,
                                   lb=estimate - 1.96*std.error,
                                   up= estimate + 1.96*std.error)) %>%
  filter(!(term %in% c("(Intercept)"))) %>%
  mutate(label=paste0("Haddad   "))


outcomes_bolsonaro <- map_df(c("covid_government", "covid_health", "covid_job"), ~
                               lm(as.numeric(get(.x)) ~ runoff_bolsonaro +
                                    income + gender + work +
                                    as.numeric(education) + age, data=d) %>%
                               tidy(.) %>%
                               mutate(outcome=.x,
                                      lb=estimate - 1.96*std.error,
                                      up= estimate + 1.96*std.error)) %>%
  filter(!(term %in% c("(Intercept)"))) %>%
  mutate(label=paste0("Bolsonaro"))





outcomes_ind <- map_df(c("covid_government", "covid_health", "covid_job"), ~
                         lm(as.numeric(get(.x)) ~ runoff_nulo +
                              income + gender + work +
                              as.numeric(education) + age, data=d) %>%
                         tidy(.) %>%
                         mutate(outcome=.x,
                                lb=estimate - 1.96*std.error,
                                up= estimate + 1.96*std.error)) %>%
  filter(!(term %in% c("(Intercept)"))) %>%
  mutate(label=paste0("Independents"))


outcomes <- rbind(outcomes_haddad, outcomes_bolsonaro, outcomes_ind) %>%
  mutate(outcome= ifelse(outcome=="covid_job",
                         "How likely is it that you \n could lose your job? ",
                         ifelse(outcome=="covid_health",
                                "How likely will your health \n be affected by COVID-19?",
                                "Has the government response \n been appropriate ?")))

outcomes_reduced <- outcomes %>% filter(str_detect(term, "runoff"))

# Graph

ggplot(outcomes_reduced, aes(y=estimate, x=label,
                             ymin=up, ymax=lb, color=label)) +
  geom_pointrange(shape=21, fill="white", size=2) +
  labs(x="", y="Point Estimates",
       title = "\nPartisanship, Risk Perceptions and Government Responses to Covid in Brazil",
       subtitle = "Regression Estimates with Controls by Income, Gender, Age, Education, and Occupation.",
       caption ="Note: Positive point-estimates when respondents show greater support \n for the government, or higher risk of losing their jobs or being infected by COVID-19") +
  geom_hline(yintercept = 0, linetype="dashed", color="darkred") +
  scale_color_manual(values=c("Bolsonaro"=pal[9], "Haddad   "=pal[1],
                              "Independents"=pal[4]),
                     name="Who would you vote for?") +
  facet_wrap(~outcome) +
  theme(plot.caption = element_text(size=12, family=my_font))

ggsave(filename="./output/figure2_will_i_get_covid.png",
       width = 12, height = 8, units = "in", pointsize = 12, bg = "white")

